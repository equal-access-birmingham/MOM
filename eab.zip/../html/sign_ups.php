<?php require_once("includes/header_require-login.php"); ?>
    <style>

.styleTable {
    margin:0in;
    margin-bottom:.0001pt;co
    font-size:10.0pt;
    font-family:"Times New Roman","serif"
}

a:link {
    color:blue;
    text-decoration:underline
}

a:visited {
    color:purple;
    text-decoration:underline
}

.style1 {
    font-size: 36px;
    color:#31704b;
    font-weight: bold;
}

.style2 {
    color:#ffffff;
    font-weight: bold;
}

.style3 {
    color:#000000;
    font-size: 18px;
}

.logo {
    width: 500px;
    margin: 15px 0 15px 0;
}
    </style>
    <title>EAB Volunteer Sign-Ups</title>
  </head>
  <body style=" background-color: grey" link="blue" vlink="purple">
    <table style="width: 800px; background-color:white" align="center" border="0" cellpadding="0" cellspacing="3">
      <tbody>
        <tr><td colspan="2" align="center"><img class="logo" src="../images/EABLogo.png" alt="EQUAL ACCESS BIRMINGHAM"></td></tr>
        <tr>
          <td colspan="2" height="50"> <div class="style1" align="center">Volunteer Sign-Ups<br></div></td>
        </tr>
        <tr>
          <td colspan="2" height="60"><div align="center"><em>You must first register in the sign-up system before volunteering. </em></div>
          </td>
        </tr>
        <tr>
          <td colspan="2" height="60" align="center">
            <div class="style3"><strong>Quick Links:</strong> 
              <a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/Volunteer_Registration/1vGN4wq2RBfME6EB3vpEHz5MkzN68HQPz6xvfdFEV7xNqerO5yZ529SXVzDAtFjjnV11XSeqaUYjAv1TfMG76HtXEuAguFV43CDn/">Volunteer Registration</a> |
              <a href="../">EAB Homepage</a> | 
              <a href="../calendar.html">Calendar</a> | 
              <a href="index.php?logout">Logout</a>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
      <table align="center" style="text-align: left; margin-left: auto; margin-right: auto; background-color: white" class="styleTable" border="1" cellpadding="1" cellspacing="1" width="800">
        <tbody align="center">
          <tr style="background-color:#31704b">
            <td width="200"> <div class="style2">Program/ Training</div> </td>
            <td width="125"> <div class="style2">Dates</div> </td>
            <td width="100"> <div class="style2">Sign-Up Form</div> </td>
            <td width="100"> <div class="style2">View Who is Signed Up</div> </td>
            <td width="125"> <div class="style2">Withdraw from Activity</div> </td>
            <td width="125"> <div class="style2">Availability</div> </td>
            <td width="150"> <div class="style2">On-Site Contact Person</div> </td>
          </tr>
          <tr>
            <td>M-Power Clinic</td>
            <td>Wednesdays</td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/M_Power_Sign_up/9HtmM3VfXM3nApEK7kxdEhUnfZmn5NnJGYxPePqee5hud4T7aajM4YA3e9meyKTWxkV9unwXFMRUX0mDN20qq81HwmhudD0h93Ab/" target="_blank">Sign-Up</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/M_Power_Sign_up_View/XpTHv3yC69RA2nBQ1Nw7ntMqszdxa8TWJA9pfgCdJ8RRDtKdOv8veNpTs42GdnE8TY6jAP649qse3yfHh4xa7n6m9DYCj8Y8Ba9Q">Volunteer List</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/M_Power_Volunteer_Change/SduO1svRQAMukdGBSyGsw2kDmAfpUuR0pMXQwN06y5x5mkPC0dVb2MhJeR4P8vzgSeV95uAfpvr15kJxEWqE2ET5Z6hYuegeZXmt/" target="_blank">Remove Yourself</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/M_Power_Sessions_Website_View/FfQmdBJW1mTw4xt61PwCt7Cv6FewAAbBw8rQZxps0GAGATCjn6s1pJ4AKdYHO5CpD1NVbexmMKJ1rXK9j3XvUjFfS1gpbg8bstdy">View Availability</a></td>
            <td>Tim Fernandez</br><a href="mailto:tjferna4@uab.edu">tjferna4@uab.edu</a></td>
          </tr>
          <tr>
            <td>EAB Clinic </td>
            <td>Sundays</td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/EAB_Clinic_Sign_up/Vwn3Rq9gUKzAAgT3GewbOK6Fd8sg12OqgC189YjBYnEPzD1BQsyxMezJFSeZp3dbe6e9ZXFpVbMv0MWyOx3PKEjOfbA8bmru7yx6/">Sign-Up</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/EAB_Clinic_Sign_up_View/qbqYyq6H9GO1zUmgKJHYqr1YqgmFUvvJPftu3wja0GmOP2ngTHuQfP3ytZ099J5dFqObUuEmYKVJtEJtP0qVtt6vuMzOrO3UyAHv">Volunteer List</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/EAB_Clinic_Volunteer_Change/5w3aVQRBvG0686nzm9hv1eYjsMhsg6v5n5j2PFEOjgYwhxawbCDXSeKwNun3b86Hv4N4DAQnqJpaenG2eU1MV6Jxze1fAYKSddXN/" target="_blank">Remove Yourself</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/EAB_Clinic_Sessions_Website_View/DW6uWOtACagx5eOQNT8ZbRybtWOfA5fT7xNjxSkDbT75XPXAHR2Rw8gddXntr5knwwGuHjt6wyOfgQC7sK94efRUvvpGATVkaEqV">View Availability</a></td>
            <td>Tim Fernandez</br><a href="mailto:tjferna4@uab.edu">tjferna4@uab.edu</a></td>
          </tr>
          <tr>
            <td>Health Screenings</td>
            <td>Monthly</td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/Screenings_Sign_up/Z5vTaTeUSW49OUF30YaG6tQbTfw2kBKX3W3XqtDwMeGHZAdvyVbXpBtu8uP2nw9dda7hP3q3N4KDmbubG6MFKzB39S3HQJuggHPO/" target="_blank">Sign-Up</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/Screenings_Sign_up_View/gr1T4Up2pOC2BVMSaVG09QbGTGwjPv6A2JRErWya8G01U8fpgz3Xf9EKdCMjZd9sCuG2zgh7Nnza3NQ8dhNb2wzC6a9XFyHR75dN" target="_blank">Volunteer List</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/Screenings_Volunteer_Change/Nnm9d3NyZXbDXXM8gdCSd2j8jTnd3tJvznVfmU3z2C8UVbBa9xD5wu14UX5YUUaAsFHyROKsExsz9mJraZrKqjEQhNytvrJTuTNd/" target="_blank">Remove Yourself</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/Screenings_Sessions_Website_View/t6ep2v3qQnJYZx2QjjDSFBQxM5SXAMThE9jXNngbuuSjXQ9q91mqDBVxUKjnQZvBdmx2VPdMbtf8HqbOn3pPvReZ75rDjsYTDq86">View Availability</a></td>
            <td>Adam Lam</br><a href="mailto:adamlam@uab.edu">adamlam@uab.edu</a></td>
          </tr>
          
          <tr>
            <td>Volunteer Trainings</td>
            <td>None</td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/Volunteer_Training_Sign_up/T44fPQB4xWtv7BNz2rz1j6fa1M4Phw8NBbkj6J9mx7wqMtThfGpQ28HhRxz9Q8NRY9A6XqmJrkxvOavX6HaT6hsdGu42pUXhEQ6q/" target="_blank">Sign-Up</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/view-perma/Volunteer_Training_Sign_up_View/mYKgCtaygTAHUOA0V99NDJXb3Ty6k5t6ePKUEz6AAJ6bnxjkmUHGMPqzBKHZ8RqGFdntG6Or5RxjyGQPO2q0mS63tXWwn61EDmQb" target="_blank">Trainee List</a></td>
            <td><a href="https://creator.zoho.com/equalaccess/volunteer-database/form-perma/Trainee_Removal_Form/n7UHuXBYSEYhXRu5RvpNGpNnFST9bZOQPTTO4Dktq9yxsUQyxv9bBCA0PMnQhzEuHjaK9qEgUV8G35QgYAMY8DEwBxsJMtzatmxW/" target="_blank">Remove Yourself</a></td>
            <td></td>
            <td>Erika Johnson</br><a href="mailto:emjohnso@uab.edu">emjohnso@uab.edu</a></td>
          </tr>
          <tr>
            <td colspan="7" height="100"></td>
          </tr>
        </tbody>
  </body>
</html>
