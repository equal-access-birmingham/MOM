<?php require_once("includes/header.php"); ?>

    <title>Donate Today!</title>

<?php require_once("includes/menu.php"); ?>

    <!-- Hero Image -->
    <div class="hero-image image5">
      <div class="container">
        <div class="row">
          <div class="col-sm-8">
            <h1>A Chance to Give Back to the Community</h1>
          </div>
        </div>
        <div class="row">
          <!-- <iframe src=""></iframe> -->
        </div>
      </div>
    </div>

<?php require_once("includes/footer.php"); ?>